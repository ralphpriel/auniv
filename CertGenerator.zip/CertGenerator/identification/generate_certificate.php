<?php
require 'fpdf/fpdf.php';

if (isset($_POST["name"]) && isset($_POST["address"]) && isset($_POST["birthday"]) && isset($_POST["contact"]) && isset($_POST["id"])) {
    $name = $_POST["name"];
    $address = $_POST["address"];
    $birthday = $_POST["birthday"];
    $contact = $_POST["contact"];
    $id = $_POST["id"];

    // Create a new PDF object
    $pdf = new FPDF();

    // Set the page orientation to landscape
    $pdf->AddPage('L', [99, 67]);

    // Set the font and style
    $pdf->SetFont('Times', 'B', 9);

    // Set the left margin
    $pdf->SetLeftMargin(7);

    // Set the background image
    $pdf->Image('aydi.png', 0, 0, 99, 67); // Adjust the path and dimensions as needed

    // Output the text and content
    $pdf->SetXY(7, $pdf->GetPageHeight() / 2.7);
    $pdf->SetFillColor(255, 255, 255); // Set background color to white
    $pdf->SetFont('Times', '', 9);

    // Set line spacing manually
    $lineHeight = 4; // Adjust the value as needed

    // Output the variables with space on each line
    $pdf->MultiCell(0, 4, '                         Name: ' . $name, 0, 'J');
    $pdf->MultiCell(0, 4, '                         Address:  ' . $address, 0, 'J');
    $pdf->MultiCell(0, 4, '                         Birthday:  ' . $birthday, 0, 'j');
    $pdf->MultiCell(0, 4, '                         Contact No.:  ' . $contact, 0, 'J');
    $pdf->MultiCell(0, 4, '                         ID No.:  ' . $id, 0, 'J');
 
    $pdf->Ln(20); // Reduce the spacing between paragraphs

    // Output the PDF as a file download
    $pdf->Output($name . '-certificate.pdf', 'D');
}
?>
