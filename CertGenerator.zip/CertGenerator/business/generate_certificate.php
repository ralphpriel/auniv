<?php
require 'fpdf/fpdf.php';

if (isset($_POST["name"]) && isset($_POST["bName"]) && isset($_POST["address"]) && isset($_POST["date"])) {
    $name = $_POST["name"];
    $bName = $_POST["bName"];
    $address = $_POST["address"];
    $date = $_POST["date"];

    // Create a new PDF object
    $pdf = new FPDF();

    // Add a page with A4 size
    $pdf->AddPage('P', 'A4');

    // Set the background image
    $pdf->Image('buss.png', 0, 0, $pdf->GetPageWidth(), $pdf->GetPageHeight(), '', false);

    // Set the font and style
    $pdf->SetFont('Times', 'B', 16); // <-- Set the font style to bold

    // Set the left margin
    $pdf->SetLeftMargin(20);

    // Output the text and content
    $pdf->SetXY(20, $pdf->GetPageHeight() / 2.2); // Set the position slightly higher
    $pdf->SetFillColor(255, 255, 255); // Set background color to white
    $pdf->SetFont('Times', '', 14);

    // Paragraph structure
    $paragraph1 = '        This is to certify that '  . $bName . '( ' . $name . '), with business address at ' .$address. ', has been granted BARANGAY BUSINESS CLEARANCE for the purpose of securing the necessary Business Permit and License from the Office of the Captain.';
    $paragraph3 = '        This clearance is Non-Transferrable, and shall be null and void upon failure of the aforementioned applicant to strictly comply with the condition of this permit';
    $paragraph4 = '        VALID UNTIL ' . $date . ' ';

    // Output each paragraph with smaller line height
    $pdf->MultiCell(0, 10, $paragraph1, 0, 'J');
    $pdf->MultiCell(0, 10, $paragraph3, 0, 'J');
    $pdf->SetFont('Times', 'B', 14); // <-- Set the font style to bold for the date paragraph
    $pdf->MultiCell(0, 81, $paragraph4, 0, 'C');

    $pdf->Ln(20); // Reduce the spacing between paragraphs

    // Output the PDF as a file download
    $pdf->Output($name . '-' . $bName . '-certificate.pdf', 'D');
} else {
    echo "Error: Required form fields are missing.";
}

?>
