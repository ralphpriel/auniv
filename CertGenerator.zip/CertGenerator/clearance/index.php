<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Generator</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/f75b807dc7.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-image: url('back.jpg'); /* Set your background image */
            background-size: cover;
            font-family: 'Roboto', Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        
        h1 {
            text-align: center;
            color: blue;
            font-weight: 900;
            font-family: Arial, Helvetica, sans-serif;

        }
        form {
            max-width: 400px;
            margin: 0 auto;
            border: none; /* Remove the border */
            padding: 30px;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.5); /* Set semi-transparent background color */
            box-shadow: 0 13px 17px rgba(0, 0, 0, 0.1);
        }
        
        input[type="text"],
        input[type="number"],
        input[type="date"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            background-color: rgba(255, 255, 255, 0.8); /* Set input background color with opacity */
            border: 1px solid #ddd;
            color: #333;
            font-size: 18px;
        }
        
        button[type="submit"] {
            background-color: blue;
            color: #fff;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            font-family: 'Roboto', Arial, sans-serif;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 2px;
            transition: background-color 0.3s;
            font-size: 20px;
        }
        
        button[type="submit"]:hover {
            background-color: darkblue;
        }
        
        label {
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <form action="generate_certificate.php" method="post" class="needs-validation" novalidate>
        <div class="form-group">
            <h1>Barangay Clearance</h1>
            <label for="name">Requester:</label>
            <input type="text" id="name" name="name" required class="form-control" placeholder="Name">
            <div class="invalid-feedback">Please enter the requester's name.</div>
        </div>
        
        <div class="form-group">
            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required class="form-control">
            <div class="invalid-feedback">Please enter the requester's age.</div>
        </div>
        
        <div class="form-group">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required class="form-control">
            <div class="invalid-feedback">Please enter the date.</div>
        </div>
        
        <button type="submit" class="btn btn-primary">
            <i class="fa-sharp fa-solid fa-circle-down"></i>
            Generate PDF
        </button>
               
    </form>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
