<?php
require 'fpdf/fpdf.php';

if (isset($_POST["name"]) && isset($_POST["age"]) && isset($_POST["date"])) {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $date = $_POST["date"];

    // Create a new PDF object
    $pdf = new FPDF();

    // Add a page with A4 size
    $pdf->AddPage('P', 'A4');

    // Set the background image
    $pdf->Image('indigency.png', 0, 0, $pdf->GetPageWidth(), $pdf->GetPageHeight(), '', false);

    // Set the font and style
    $pdf->SetFont('Times', 'B', 16);

    // Set the left margin
    $pdf->SetLeftMargin(20);

    // Output the text and content
    $pdf->SetXY(20, $pdf->GetPageHeight() / 2.2); // Set the position slightly higher
    $pdf->SetFillColor(255, 255, 255); // Set background color to white
    $pdf->SetFont('Times', '', 14);

    // Paragraph structure
    $paragraph1 = '        This is to certify that ' . $name . ', ' . $age . ' years old, and a resident of Barangay Bagumbayan, Caloocan City, is known to be of good moral character and a law-abiding citizen of the community.';
    $paragraph3 = '        To certify further, that he/she has no derogatory and/or criminal record filed in this barangay.';
    $paragraph4 = '        ISSUED this ' . $date . ' at Barangay Bagumbayan, Caloocan City upon request of the interested party for whatever legal purpose it may serve.';

    // Output each paragraph with smaller line height
    $pdf->MultiCell(0, 10, $paragraph1, 0, 'J');
    $pdf->MultiCell(0, 10, $paragraph3, 0, 'J');
    $pdf->MultiCell(0, 10, $paragraph4, 0, 'J');

    $pdf->Ln(20); // Reduce the spacing between paragraphs

    // Output the PDF as a file download
    $pdf->Output($name . '-' . $age . '-certificate.pdf', 'D');
} else {
    echo "Error: Required form fields are missing.";
}
?>
